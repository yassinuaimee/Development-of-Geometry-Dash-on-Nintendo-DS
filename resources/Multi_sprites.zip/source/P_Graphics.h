/*
 * P_Graphics.h
 *
 *  Created on: Dec 19, 2019
 *      Author: nds
 */

#ifndef P_GRAPHICS_H_
#define P_GRAPHICS_H_

int x1, y, x2, y2, x3, y3;

void configureGraphics_Main();

void configSprites_Main();

#endif /* P_GRAPHICS_H_ */
